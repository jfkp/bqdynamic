# wiki_ingest.py
import os
import json
import subprocess
import tempfile
from pathlib import Path
from opensearchpy import OpenSearch
from sentence_transformers import SentenceTransformer

OPENSEARCH = os.getenv('OPENSEARCH_HOST','http://localhost:9200')
INDEX = 'docs'
EMBED_MODEL = 'all-MiniLM-L6-v2'

client = OpenSearch(OPENSEARCH)
model = SentenceTransformer(EMBED_MODEL)

WIKI_DUMP_URL = 'https://dumps.wikimedia.org/enwiki/latest/enwiki-latest-pages-articles.xml.bz2'

def run_wikiextractor(dump_path, out_dir):
    cmd = [
        'wikiextractor',
        str(dump_path),
        '-o', str(out_dir),
        '--json',
        '--processes', '4',
        '--bytes', '50M'
    ]
    subprocess.run(cmd, check=True)

def parse_and_index(extracted_dir, max_docs=2000):
    count = 0
    for path in Path(extracted_dir).rglob('*.json'):
        with open(path, 'r', encoding='utf-8') as f:
            for line in f:
                if count >= max_docs:
                    return count
                try:
                    obj = json.loads(line)
                    title = obj.get('title')
                    text = obj.get('text','')
                except Exception:
                    continue
                # chunk the text
                chunks = [text[i:i+1500] for i in range(0,len(text),1500)]
                for i,ch in enumerate(chunks):
                    emb = model.encode(ch).tolist()
                    body = {
                        'title': title,
                        'text': ch,
                        'metadata': {'page': title, 'chunk': i},
                        'embedding': emb,
                        'url': obj.get('url')
                    }
                    client.index(index=INDEX, body=body)
                count += 1
    return count

def run_wikipedia_ingest():
    tmp = tempfile.mkdtemp()
    dump_path = Path(tmp)/'enwiki-latest-pages-articles.xml.bz2'
    # download dump
    import requests
    with requests.get(WIKI_DUMP_URL, stream=True) as r:
        r.raise_for_status()
        with open(dump_path, 'wb') as f:
            for chunk in r.iter_content(chunk_size=8192):
                f.write(chunk)
    # run WikiExtractor
    out_dir = Path(tmp)/'extracted'
    out_dir.mkdir(parents=True, exist_ok=True)
    run_wikiextractor(dump_path, out_dir)
    # index sample
    n = parse_and_index(out_dir, max_docs=500)
    print(f'Indexed {n} pages (sample)')
