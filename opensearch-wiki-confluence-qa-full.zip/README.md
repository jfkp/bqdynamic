# OpenSearch + Wikipedia + Confluence Q&A — Full Stack

This repository provides a full prototype integrating:
- OpenSearch (text + kNN vector)
- Wikipedia ingest (WikiExtractor) with Airflow DAGs
- Confluence ingest via REST API with Airflow DAGs
- Cross-encoder reranker service
- FastAPI Q&A service
- Minimal React frontend (Vite)

## Quickstart (local)

1. Start the unified stack:
   ```bash
   docker compose up -d
   ```

2. Initialize Airflow database (once):
   ```bash
   docker compose run --rm airflow-webserver airflow db init
   docker compose run --rm airflow-webserver airflow users create --username admin --password admin --firstname Admin --lastname User --role Admin --email admin@example.com
   ```

3. Install Python deps locally (optional) and index sample docs:
   ```bash
   pip install -r api/requirements.txt
   python ingest_sample.py
   ```

4. Start reranker (if not running in Docker):
   ```bash
   uvicorn api/reranker_service:app --host 0.0.0.0 --port 8100
   ```

5. Start API (if not running in Docker):
   ```bash
   uvicorn api/qa_service:app --host 0.0.0.0 --port 8000
   ```

6. Frontend:
   ```bash
   cd frontend
   npm install
   npm run dev
   ```

## Environment variables

Set Confluence variables if using Confluence ingest:
```
CONFLUENCE_BASE, CONFLUENCE_USER, CONFLUENCE_TOKEN
```

## Notes

- WikiExtractor is required for the Wikipedia DAG. Install via `pip install wikiextractor`.
- The ingest scripts are production-ready starting points; adjust chunking, embedding model, and indexing settings for scale.
