# dags/confluence_ingest_test_dag.py
from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime, timedelta
from confluence_ingest import ingest_space

def run_confluence_test_ingest():
    # For a quick test, ingest just a few pages using the existing ingest_space function
    ingest_space("ENG", max_pages=5)

default_args = {
    "owner": "qa-team",
    "depends_on_past": False,
    "start_date": datetime(2025, 1, 1),
    "retries": 0,
}

with DAG(
    "confluence_ingest_test",
    default_args=default_args,
    schedule_interval="@daily",
    catchup=False,
    tags=["confluence","opensearch","qa","test"]
) as dag:
    ingest_test = PythonOperator(
        task_id="ingest_confluence_test",
        python_callable=run_confluence_test_ingest,
    )
