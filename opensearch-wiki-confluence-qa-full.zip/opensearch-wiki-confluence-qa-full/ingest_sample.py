# ingest_sample.py
import json
from opensearchpy import OpenSearch
from sentence_transformers import SentenceTransformer

OPENSEARCH_HOST = "http://localhost:9200"
INDEX = "docs"
EMBED_DIM = 384

client = OpenSearch(OPENSEARCH_HOST)
model = SentenceTransformer("all-MiniLM-L6-v2")

# create index if not exists
with open("opensearch_mapping.json","r") as f:
    mapping = json.load(f)

if not client.indices.exists(INDEX):
    client.indices.create(index=INDEX, body=mapping)

# sample docs
docs = [
    {"title": "Transfer learning", "text": "Transfer learning is a technique in machine learning where a model trained on one task is repurposed on a second related task.", "metadata": {"source":"sample"}, "url": "https://en.wikipedia.org/wiki/Transfer_learning"},
    {"title": "Neural networks", "text": "Neural networks are computing systems inspired by biological neural networks.", "metadata": {"source":"sample"}, "url": "https://en.wikipedia.org/wiki/Artificial_neural_network"},
    {"title": "OpenSearch", "text": "OpenSearch is a community-driven, open source search and analytics suite derived from Elasticsearch.", "metadata": {"source":"sample"}, "url": "https://opensearch.org"}
]

for i,d in enumerate(docs):
    emb = model.encode(d["text"]).tolist()
    body = {"title": d["title"], "text": d["text"], "metadata": d["metadata"], "embedding": emb, "url": d["url"]}
    client.index(index=INDEX, id=f"sample_{i}", body=body, refresh=True)

print("Indexed sample docs")
