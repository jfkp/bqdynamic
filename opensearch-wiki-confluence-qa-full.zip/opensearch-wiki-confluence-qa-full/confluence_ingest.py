# confluence_ingest.py
import os
import requests
from bs4 import BeautifulSoup
from opensearchpy import OpenSearch
from sentence_transformers import SentenceTransformer
import json
from typing import List, Dict

CONFLUENCE_BASE = os.getenv("CONFLUENCE_BASE")  # e.g. https://your-domain.atlassian.net/wiki
CONFLUENCE_USER = os.getenv("CONFLUENCE_USER")
CONFLUENCE_TOKEN = os.getenv("CONFLUENCE_TOKEN")
OPENSEARCH = os.getenv("OPENSEARCH_HOST","http://localhost:9200")

INDEX = "confluence"
EMBED_MODEL = "all-MiniLM-L6-v2"

client = OpenSearch(OPENSEARCH)
model = SentenceTransformer(EMBED_MODEL)

def fetch_pages(space="ENG", limit=50):
    url = f"{CONFLUENCE_BASE}/rest/api/content"
    params = {
        "spaceKey": space,
        "limit": limit,
        "expand": "body.storage"
    }
    resp = requests.get(url, params=params, auth=(CONFLUENCE_USER, CONFLUENCE_TOKEN))
    resp.raise_for_status()
    return resp.json().get("results", [])

def clean_html(html):
    soup = BeautifulSoup(html, "html.parser")
    return soup.get_text(" ", strip=True)

def ingest_space(pages,space):
    #pages = fetch_pages(space, limit=max_pages)
    for page in pages:
        page_id = page["id"]
        title = page["title"]
        # Get the ancestors list from the response
        url = page['url']
        parent = page['parent']
        attachments=page['attachments']
        comments = page['comments']
        text = clean_html(page['content'])
        chunks = [text[i:i+1500] for i in range(0, len(text), 1500)]
        for i, chunk in enumerate(chunks):
            emb = model.encode(chunk).tolist()
            doc = {
                "title": title,
                "url": url,
                "text": chunk,
                "parent" : parent, 
                "metadata": {"space": space, "page_id": page_id, "chunk": i},
                "embedding": emb,
            }
            client.index(index=INDEX, body=doc)
    print(f"Ingested {len(pages)} pages from space {space}")




def get_page_with_children(page_id: str, base_url: str, api_token: str, email: str) -> dict:
    """
    Récupère une page Confluence et ses pages enfants en utilisant l'API REST v2.

    Args:
        page_id: L'identifiant unique de la page Confluence.
        base_url: L'URL de base de votre instance Confluence (ex: 'https://votresite.atlassian.net').
        api_token: Le jeton d'API généré dans votre compte Atlassian.
        email: Votre adresse email de connexion à Atlassian.

    Returns:
        Un dictionnaire contenant les données de la page parent et la liste des enfants,
        ou un dictionnaire vide si une erreur survient.
    """
    headers = {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
    }

    # URL de l'API pour récupérer une page
    page_url = f"{base_url}/wiki/api/v2/pages/{page_id}"
    
    # URL de l'API pour récupérer les enfants d'une page
    children_url = f"{base_url}/wiki/api/v2/pages/{page_id}/children"

    results = {
        'parent_page': None,
        'children': []
    }

    try:
        # 1. Récupération de la page parent
        response_parent = requests.get(page_url, headers=headers, auth=(email, api_token))
        response_parent.raise_for_status() # Lève une exception si le statut est une erreur (4xx ou 5xx)
        results['parent_page'] = response_parent.json()

        # 2. Récupération des pages enfants
        response_children = requests.get(children_url, headers=headers, auth=(email, api_token))
        response_children.raise_for_status()
        
        # L'API des enfants renvoie un objet JSON avec une liste dans la clé 'results'
        results['children'] = response_children.json().get('results', [])

    except requests.exceptions.HTTPError as err:
        print(f"Erreur HTTP: {err}")
    except requests.exceptions.RequestException as err:
        print(f"Une erreur s'est produite: {err}")
    
    return results



# def _fetch_paginated_data(url: str, auth: tuple) -> list:
#     """
#     Fonction utilitaire pour gérer la pagination et récupérer toutes les données d'un endpoint.
#     """
#     all_data = []
#     while url:
#         try:
#             response = requests.get(url, auth=auth)
#             response.raise_for_status()
#             data = response.json()
            
#             # Les données se trouvent généralement dans la clé 'results'
#             all_data.extend(data.get('results', []))

#             # Vérifier s'il y a un lien pour la page suivante
#             next_link = data.get('_links', {}).get('next')
#             if next_link:
#                 url = f"{response.url.split('?')[0]}{next_link}"
#             else:
#                 url = None
#         except requests.exceptions.HTTPError as err:
#             print(f"Erreur HTTP: {err}")
#             return []
#         except requests.exceptions.RequestException as err:
#             print(f"Une erreur de connexion s'est produite: {err}")
#             return []
            
#     return all_data


def _fetch_paginated_data(url: str, auth: tuple) -> List[Dict]:
    """
    Fonction utilitaire pour gérer la pagination et récupérer toutes les données d'un endpoint.
    """
    all_data = []
    cursor = None
    
    while True:
        current_url = url
        if cursor:
            current_url += f"&cursor={cursor}" if '?' in current_url else f"?cursor={cursor}"
        
        try:
            response = requests.get(current_url, auth=auth)
            response.raise_for_status()
            data = response.json()
            
            # Les données se trouvent dans la clé 'results' pour l'API v2
            all_data.extend(data.get('results', []))

            # L'API v2 utilise un 'cursor' pour la pagination
            cursor = data.get('cursor')
            if not cursor:
                break
        except requests.exceptions.RequestException as err:
            print(f"Erreur lors de l'appel à {current_url}: {err}")
            return []
            
    return all_data




def get_all_confluence_pages(base_url: str, api_token: str, email: str,space: str) -> list:
    """
    Récupère toutes les pages de tous les espaces d'une instance Confluence.

    Args:
        base_url: L'URL de base de votre instance Confluence.
        api_token: Le jeton d'API de votre compte Atlassian.
        email: Votre adresse email de connexion.

    Returns:
        Une liste de tous les objets de page trouvés.
    """
    auth = (email, api_token)
    all_pages = []

    # 1. Récupérer tous les espaces
    spaces_url = f"{base_url}/wiki/api/v2/spaces"
    print("Récupération des espaces en cours...")
    all_spaces = _fetch_paginated_data(spaces_url, auth)
    print(f"{len(all_spaces)} espaces trouvés.")

    # 2. Pour chaque espace, récupérer toutes ses pages
    for space in all_spaces:
        if space.get('name') == MySpace:
            space_id = space.get('id')
            space_key = space.get('key')
            print(f"  -> Récupération des pages pour l'espace '{space_key}' ({space_id})...")            
            pages_url = f"{base_url}/wiki/api/v2/spaces/{space_id}/pages"
            space_pages = _fetch_paginated_data(pages_url, auth)
            all_pages.extend(space_pages)

    return all_pages



def get_all_confluence_pages_full(base_url: str, api_token: str, email: str,space: str) -> List[Dict]:
    """
    Récupère toutes les pages, ainsi que leurs commentaires et pièces jointes, de tous les espaces.

    Args:
        base_url: L'URL de base de votre instance Confluence.
        api_token: Le jeton d'API de votre compte Atlassian.
        email: Votre adresse email de connexion.

    Returns:
        Une liste de tous les objets de page enrichis.
    """
    auth = (email, api_token)
    all_pages = []

    # 1. Récupérer tous les espaces
    spaces_url = f"{base_url}/wiki/api/v2/spaces"
    print("Récupération des espaces en cours...")
    all_spaces = _fetch_paginated_data(spaces_url, auth)
    print(f"{len(all_spaces)} espaces trouvés.")

    # 2. Pour chaque espace, récupérer toutes ses pages, commentaires et pièces jointes
    for space in all_spaces:
        space_key = space.get('key')
        space_id = space.get('id')
        if space.get('name') == MySpace:

            print(f"\n-> Récupération des pages et de leur contenu pour l'espace '{space_key}'...")
            
            pages_url = f"{base_url}/wiki/api/v2/spaces/{space_id}/pages?limit=100"
            space_pages = _fetch_paginated_data(pages_url, auth)

            for page in space_pages:
                page_id = page.get('id')
                content_url = f"{base_url}/wiki/rest/api/content/{page_id}?expand=body.storage,attachments,comments"
                content_response = requests.get(content_url, auth=auth)
                content_response.raise_for_status()
                content_data = content_response.json()
                url = f"{CONFLUENCE_BASE}/{page['_links']['webui']}"
                page['url'] = url
                page_content = content_data.get('body', {}).get('storage', {}).get('value', 'Contenu non disponible')
                page['content'] = page_content
                # Récupération des pièces jointes de la page
                attachments = content_data.get('attachments', {}).get('results', [])
                page['attachments'] = attachments
                # Récupération des commentaires de la page
                comments = content_data.get('comments', {}).get('comments', [])
                page['comments'] = comments
                 # Get the ancestors list from the response
                ancestors = page.get('ancestors', [])
        
                 # The parent is the last item in the ancestors list
                if ancestors:
                    parent_page = ancestors[-1]
                    # Store the parent data as metadata in a new key
                    page['parent'] = {'parent': parent_page}
            
                else:
                    # If there are no ancestors, the page is a top-level page
                    page['parent'] = {'parent': None}


                all_pages.append(page)
                print(f"   -> Page '{page.get('title')}': {len(attachments)} attachements, {len(comments)} commentaires.")

    return all_pages


# --- Exemple d'utilisation ---
if __name__ == "__main__":
    # Remplacer ces valeurs par les vôtres
    CONFLUENCE_BASE_URL = "https://votre-site.atlassian.net"
    YOUR_EMAIL = "jkpodar@gmail.com"
    YOUR_API_TOKEN = "votre_token_api_atlassian"
    PAGE_ID_TO_FETCH = "123456789" # Remplacer par l'ID de la page que vous voulez récupérer
    MySpace="spaces"

    all_confluence_pages = get_all_confluence_pages_full(
        base_url=CONFLUENCE_BASE_URL,
        api_token=YOUR_API_TOKEN,
        email=YOUR_EMAIL,
        space=MySpace
    )

    if all_confluence_pages:

        print("\n--- Récupération terminée ---")
        print(f"Nombre total de pages trouvées : {len(all_confluence_pages)}")
        print("\nExemple des 5 premières pages :")
        for page in all_confluence_pages[:5]:
            print(f" ->  Page '{page.get('title')}': ID: '{page.get('id')}', '{len(page.get('attachments'))}' \
                  attachements, '{len(page.get('comments'))}' commentaires  '{page['parent']}' parent . ")
  
            # page_data = get_page_with_children(
            # page_id=page.get('id'),
            # base_url=CONFLUENCE_BASE_URL,
            # api_token=YOUR_API_TOKEN,
            # email=YOUR_EMAIL
            # )

            # if page_data.get('parent_page'):
            #     parent_title = page_data['parent_page'].get('title')
            #     print(f"Page parente: '{parent_title}'")
            #     print(f"Nombre de pages enfants trouvées: {len(page_data['children'])}")
            #     ingest_space()
            #     if page_data['children']:
            #         print("\nPages enfants:")
            #         for child in page_data['children']:
            #             print(f"- Titre: {child.get('title')}, ID: {child.get('id')}")
            # else:
            #     print("Échec de la récupération des données de la page.")
    else:
        print("Aucune page n'a pu être récupérée. Vérifiez vos informations d'identification.")

    