import React, { useState } from 'react'

export default function App(){
  const [q, setQ] = useState('')
  const [resp, setResp] = useState(null)
  const ask = async () => {
    const r = await fetch('http://localhost:8000/qa', {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({q})
    })
    const j = await r.json()
    setResp(j)
  }
  return (
    <div style={{fontFamily:'Arial', padding:20}}>
      <h1>Q&A Frontend</h1>
      <input style={{width:'60%'}} value={q} onChange={e=>setQ(e.target.value)} placeholder="Ask a question" />
      <button onClick={ask} style={{marginLeft:10}}>Ask</button>
      {resp && (
        <div style={{marginTop:20}}>
          <h3>Prompt (for LLM)</h3>
          <pre style={{whiteSpace:'pre-wrap'}}>{resp.prompt}</pre>
          <h3>Sources</h3>
          <ul>
            {resp.sources.map((s,i)=>(<li key={i}>{s.source} - {s.title || s.id} {s.url?`(${s.url})`:''}</li>))}
          </ul>
        </div>
      )}
    </div>
  )
}
