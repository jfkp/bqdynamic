# dags/wikipedia_ingest_test_dag.py
from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime, timedelta
from wiki_ingest import run_wikipedia_ingest

def run_wikipedia_test_ingest():
    import tempfile, requests
    from pathlib import Path
    from wiki_ingest import run_wikiextractor, parse_and_index, WIKI_DUMP_URL

    tmp = tempfile.mkdtemp()
    dump_path = Path(tmp)/'enwiki-sample.xml.bz2'
    with requests.get(WIKI_DUMP_URL, stream=True) as r:
        r.raise_for_status()
        with open(dump_path, 'wb') as f:
            for i, chunk in enumerate(r.iter_content(chunk_size=8192)):
                f.write(chunk)
                if i > 200:
                    break
    out_dir = Path(tmp)/'extracted'
    out_dir.mkdir(parents=True, exist_ok=True)
    run_wikiextractor(dump_path, out_dir)
    n = parse_and_index(out_dir, max_docs=10)
    print(f"[TEST] Indexed {n} pages from small dump fragment")
