from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime, timedelta
from wiki_ingest import run_wikiextractor, parse_and_index

default_args = {'owner':'qa-team','depends_on_past':False,'start_date':datetime(2025,1,1),'retries':1,'retry_delay':timedelta(minutes=5)}

with DAG('wiki_ingest', default_args=default_args, schedule_interval='@weekly', catchup=False) as dag:
    ingest = PythonOperator(task_id='ingest_wiki', python_callable=lambda: print('Run Wiki extractor and parse/index'))
