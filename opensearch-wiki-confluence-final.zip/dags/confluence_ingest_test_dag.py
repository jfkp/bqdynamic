from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime, timedelta
from confluence_ingest import ingest_space

def ingest_test():
    ingest_space('ENG', max_pages=5)

default_args = {'owner':'qa-team','depends_on_past':False,'start_date':datetime(2025,1,1),'retries':0}

with DAG('confluence_ingest_test', default_args=default_args, schedule_interval='@daily', catchup=False) as dag:
    ingest = PythonOperator(task_id='ingest_confluence_test', python_callable=ingest_test)
