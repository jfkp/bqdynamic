# wiki_ingest.py - skeleton that runs WikiExtractor and indexes into OpenSearch
import os, subprocess, tempfile
from pathlib import Path
from opensearchpy import OpenSearch
from sentence_transformers import SentenceTransformer
import json

OPENSEARCH = os.getenv('OPENSEARCH_HOST','http://localhost:9200')
INDEX = 'docs'
MODEL = 'all-MiniLM-L6-v2'

client = OpenSearch(OPENSEARCH)
model = SentenceTransformer(MODEL)

def run_wikiextractor(dump_path, out_dir):
    cmd = ['wikiextractor', str(dump_path), '-o', str(out_dir), '--json', '--processes', '4']
    subprocess.run(cmd, check=True)

def parse_and_index(extracted_dir, max_docs=500):
    count = 0
    for path in Path(extracted_dir).rglob('*.json'):
        with open(path, 'r', encoding='utf-8') as fh:
            for line in fh:
                if count >= max_docs:
                    return count
                obj = json.loads(line)
                title = obj.get('title')
                text = obj.get('text','')
                chunks = [text[i:i+1500] for i in range(0,len(text),1500)]
                for i,ch in enumerate(chunks):
                    emb = model.encode(ch).tolist()
                    doc = {'title':title,'text':ch,'embedding':emb,'url':obj.get('url')}
                    client.index(index=INDEX, body=doc)
                count += 1
    return count

if __name__=='__main__':
    print('Run run_wikiextractor() and parse_and_index() as needed')
