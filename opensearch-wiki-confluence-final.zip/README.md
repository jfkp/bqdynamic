# OpenSearch + Wikipedia + Confluence Q&A (full regenerated)

This repository includes:
- OpenSearch + OpenSearch Dashboards
- FastAPI QA service and reranker service
- Confluence ingest with OpenAI image descriptions
- Wiki ingest skeleton (WikiExtractor)
- Airflow DAGs for scheduling ingest jobs
- Minimal React frontend (Vite)

## Environment vars (important)
- CONFLUENCE_BASE, CONFLUENCE_USER, CONFLUENCE_TOKEN
- OPENAI_API_KEY
- OPENSEARCH_HOST (optional)

## Quick start (local)
1. Build and start services:
   docker compose up -d --build
2. Index sample docs locally (optional):
   pip install -r api/requirements.txt
   python ingest_sample.py
3. Start frontend:
   cd frontend && npm install && npm run dev
4. Use Airflow UI at http://localhost:8080 (the image-based ingestion jobs will be available as DAGs)
