import os, requests
from bs4 import BeautifulSoup
from opensearchpy import OpenSearch
from sentence_transformers import SentenceTransformer
import openai
from urllib.parse import urljoin

CONFLUENCE_BASE = os.getenv('CONFLUENCE_BASE')
CONFLUENCE_USER = os.getenv('CONFLUENCE_USER')
CONFLUENCE_TOKEN = os.getenv('CONFLUENCE_TOKEN')
OPENSEARCH = os.getenv('OPENSEARCH_HOST','http://localhost:9200')
OPENAI_API_KEY = os.getenv('OPENAI_API_KEY')

INDEX = 'confluence'
MODEL = 'all-MiniLM-L6-v2'

client = OpenSearch(OPENSEARCH)
embed_model = SentenceTransformer(MODEL)
openai.api_key = OPENAI_API_KEY

def fetch_pages(space='ENG', limit=50):
    url = f"{CONFLUENCE_BASE}/rest/api/content"
    params = {'spaceKey':space, 'limit':limit, 'expand':'body.storage,version,ancestors'}
    r = requests.get(url, params=params, auth=(CONFLUENCE_USER, CONFLUENCE_TOKEN))
    r.raise_for_status()
    return r.json().get('results', [])

def fetch_attachment_url(page_id):
    url = f"{CONFLUENCE_BASE}/rest/api/content/{page_id}/child/attachment"
    r = requests.get(url, auth=(CONFLUENCE_USER, CONFLUENCE_TOKEN))
    r.raise_for_status()
    data = r.json()
    results = data.get('results', [])
    urls = []
    for a in results:
        links = a.get('_links', {})
        download = links.get('download')
        if download:
            urls.append(urljoin(CONFLUENCE_BASE, download))
    return urls

def describe_image_with_openai(image_url):
    try:
        # Use chat completions with image_url block (depends on OpenAI SDK capabilities)
        resp = openai.chat.completions.create(
            model='gpt-4o-mini',
            messages=[{'role':'user','content':[{'type':'text','text':'Describe this image in detail, including objects, text, charts, and any important labels.'},
                                               {'type':'image_url','image_url':{'url':image_url}}]}]
        )
        return resp.choices[0].message.content.strip()
    except Exception as e:
        return '[image description unavailable]'

def clean_and_describe(html, page_id):
    soup = BeautifulSoup(html, 'html.parser')
    images = []
    # find img tags and replace with description placeholders
    for img in soup.find_all('img'):
        src = img.get('src')
        full = src if src.startswith('http') else urljoin(CONFLUENCE_BASE, src)
        desc = describe_image_with_openai(full)
        images.append({'url': full, 'description': desc})
        img.replace_with(f"[Image description: {desc}]")
    # also fetch attachments and describe them
    try:
        attachments = fetch_attachment_url(page_id)
        for a in attachments:
            desc = describe_image_with_openai(a)
            images.append({'url': a, 'description': desc})
    except Exception:
        pass
    text = soup.get_text(' ', strip=True)
    return text, images

def ingest_space(space='ENG', max_pages=100):
    pages = fetch_pages(space, limit=max_pages)
    for page in pages:
        page_id = page.get('id')
        title = page.get('title')
        url = urljoin(CONFLUENCE_BASE, page.get('_links', {}).get('webui',''))
        html = page.get('body', {}).get('storage', {}).get('value','')
        text, images = clean_and_describe(html, page_id)
        chunks = [text[i:i+1500] for i in range(0, len(text), 1500)]
        for i,ch in enumerate(chunks):
            emb = embed_model.encode(ch).tolist()
            doc = {'title':title, 'url':url, 'text':ch, 'metadata':{'space':space,'page_id':page_id,'chunk':i}, 'embedding':emb, 'images': images}
            client.index(index=INDEX, body=doc)
    print(f'Ingested {len(pages)} pages from space {space}')
