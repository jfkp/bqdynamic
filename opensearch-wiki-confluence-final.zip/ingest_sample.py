import json
from opensearchpy import OpenSearch
from sentence_transformers import SentenceTransformer

OPENSEARCH_HOST = "http://localhost:9200"
INDEX = "docs"

client = OpenSearch(OPENSEARCH_HOST)
model = SentenceTransformer("all-MiniLM-L6-v2")

mapping = {
  "settings": {"index": {"knn": True}},
  "mappings": {"properties": {"title":{"type":"text"}, "text":{"type":"text"}, "embedding":{"type":"knn_vector","dimension":384}, "url":{"type":"keyword"}}}
}

if not client.indices.exists(INDEX):
    client.indices.create(index=INDEX, body=mapping)

docs = [
    {"title":"Transfer learning","text":"Transfer learning is a technique...","url":"https://en.wikipedia.org/wiki/Transfer_learning"},
    {"title":"Neural networks","text":"Neural networks are computing systems...","url":"https://en.wikipedia.org/wiki/Artificial_neural_network"}
]

for i,d in enumerate(docs):
    emb = model.encode(d["text"]).tolist()
    body = {"title":d["title"], "text":d["text"], "embedding":emb, "url":d["url"]}
    client.index(index=INDEX, id=f"sample_{i}", body=body, refresh=True)

print('Indexed sample docs')
