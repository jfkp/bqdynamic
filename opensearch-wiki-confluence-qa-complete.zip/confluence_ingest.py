import os, requests
from bs4 import BeautifulSoup
from opensearchpy import OpenSearch
from sentence_transformers import SentenceTransformer
import openai

CONFLUENCE_BASE = os.getenv("CONFLUENCE_BASE")
CONFLUENCE_USER = os.getenv("CONFLUENCE_USER")
CONFLUENCE_TOKEN = os.getenv("CONFLUENCE_TOKEN")
OPENSEARCH = os.getenv("OPENSEARCH_HOST","http://localhost:9200")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

INDEX = "confluence"
EMBED_MODEL = "all-MiniLM-L6-v2"

client = OpenSearch(OPENSEARCH)
model = SentenceTransformer(EMBED_MODEL)
openai.api_key = OPENAI_API_KEY

def fetch_pages(space="ENG", limit=50):
    url = f"{CONFLUENCE_BASE}/rest/api/content"
    params = {"spaceKey": space, "limit": limit, "expand": "body.storage"}
    resp = requests.get(url, params=params, auth=(CONFLUENCE_USER, CONFLUENCE_TOKEN))
    resp.raise_for_status()
    return resp.json().get("results", [])

def describe_image_with_llm(img_url):
    try:
        resp = openai.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role":"user","content":[{"type":"text","text":"Describe this image in detail."},
                                                {"type":"image_url","image_url":{"url":img_url}}]}]
        )
        return resp.choices[0].message.content.strip()
    except Exception as e:
        return "[Image description unavailable]"

def clean_html_with_images(html):
    soup = BeautifulSoup(html, "html.parser")
    for img in soup.find_all("img"):
        src = img.get("src")
        full_url = f"{CONFLUENCE_BASE}{src}" if src.startswith("/") else src
        desc = describe_image_with_llm(full_url)
        img.replace_with(f"[Image description: {desc}]")
    return soup.get_text(" ", strip=True)

def ingest_space(space="ENG", max_pages=100):
    pages = fetch_pages(space, limit=max_pages)
    for page in pages:
        page_id = page["id"]
        title = page["title"]
        url = f"{CONFLUENCE_BASE}{page['_links']['webui']}"
        text = clean_html_with_images(page["body"]["storage"]["value"])
        chunks = [text[i:i+1500] for i in range(0,len(text),1500)]
        for i,ch in enumerate(chunks):
            emb = model.encode(ch).tolist()
            doc = {"title": title, "url": url, "text": ch,
                   "metadata":{"space":space,"page_id":page_id,"chunk":i},
                   "embedding":emb}
            client.index(index=INDEX, body=doc)
    print(f"Ingested {len(pages)} pages from space {space}")
