# OpenSearch + Wiki + Confluence QA with LLM Image Description

## Features
- OpenSearch indexing for text + embeddings
- Confluence ingestion with GPT-4o image descriptions
- Airflow DAGs for ingestion scheduling
- Placeholder Wiki ingestion pipeline
- Ready for QA API and frontend integration

## Setup
1. Set environment variables:
   - CONFLUENCE_BASE, CONFLUENCE_USER, CONFLUENCE_TOKEN, OPENAI_API_KEY
2. Run: `docker compose up -d`
3. Use Airflow DAGs for ingestion scheduling
