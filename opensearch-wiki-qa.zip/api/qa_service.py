# api/qa_service.py
from fastapi import FastAPI
from pydantic import BaseModel
import requests
from opensearchpy import OpenSearch
from sentence_transformers import SentenceTransformer

app = FastAPI()
client = OpenSearch("http://opensearch:9200")
model = SentenceTransformer("all-MiniLM-L6-v2")
INDEX = "docs"

class Query(BaseModel):
    q: str

def fetch_wikipedia_snippets(query, limit=3):
    s_url = "https://en.wikipedia.org/w/api.php"
    params = {
        "action": "query",
        "list": "search",
        "srsearch": query,
        "utf8": 1,
        "format": "json",
        "srlimit": limit
    }
    r = requests.get(s_url, params=params, timeout=10).json()
    results = []
    for item in r.get("query", {}).get("search", []):
        title = item["title"]
        page = requests.get("https://en.wikipedia.org/api/rest_v1/page/summary/" + title).json()
        results.append({"source": "wikipedia", "title": title, "text": page.get("extract","")})
    return results

def opensearch_text_search(q, k=5):
    body = {
        "size": k,
        "query": {
            "multi_match": {
                "query": q,
                "fields": ["title^2", "text"]
            }
        }
    }
    res = client.search(index=INDEX, body=body)
    hits = []
    for hit in res["hits"]["hits"]:
        hits.append({
            "source": "opensearch",
            "id": hit["_id"],
            "score": float(hit["_score"]) if hit.get("_score") is not None else 0.0,
            "title": hit["_source"].get("title"),
            "text": hit["_source"].get("text"),
            "metadata": hit["_source"].get("metadata",{})
        })
    return hits

def opensearch_vector_search(q, k=5):
    vec = model.encode(q).tolist()
    body = {
      "size": k,
      "query": {
        "knn": {
          "embedding": {
            "vector": vec,
            "k": k
          }
        }
      }
    }
    try:
        res = client.search(index=INDEX, body=body)
    except Exception as e:
        return []
    hits = []
    for hit in res["hits"]["hits"]:
        hits.append({
            "source":"opensearch_vector",
            "id": hit["_id"],
            "score": hit["_score"],
            "title": hit["_source"].get("title"),
            "text": hit["_source"].get("text")
        })
    return hits

def fuse_results(*lists, k=6):
    combined = []
    for lst in lists:
        for item in lst:
            combined.append(item)
    seen = set()
    unique = []
    for it in combined:
        key = (it.get("source"), it.get("id") or it.get("title"), (it.get("text") or "")[:120])
        if key in seen:
            continue
        seen.add(key)
        unique.append(it)
    unique.sort(key=lambda x: x.get("score", 0.0), reverse=True)
    return unique[:k]

def build_prompt(question, passages):
    prompt = "Answer the question using ONLY the following passages. Include citations to the source.\n\n"
    for i,p in enumerate(passages):
        src = p.get("source")+ " / " + (p.get("title") or p.get("id") or "doc")
        prompt += f"PASSAGE {i+1} (source: {src}):\n{p['text']}\n\n"
    prompt += f"QUESTION: {question}\n\nAnswer (with short citations):"
    return prompt

@app.post('/qa')
def qa(query: Query):
    qtxt = query.q
    wiki = fetch_wikipedia_snippets(qtxt, limit=3)
    os_hits = opensearch_text_search(qtxt, k=5)
    vec_hits = opensearch_vector_search(qtxt, k=5)
    combined = fuse_results(wiki, os_hits, vec_hits, k=6)
    prompt = build_prompt(qtxt, combined)
    return {"prompt": prompt, "sources": combined}
