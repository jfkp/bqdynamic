# simulate_eval.py
import time
from opensearchpy import OpenSearch
import requests

OS = OpenSearch('http://localhost:9200')
RERANK_URL = 'http://localhost:8100/rerank'

def retrieve(query, k=10):
    t0 = time.time()
    res = OS.search(index='docs', body={'size':k,'query':{'multi_match':{'query':query,'fields':['title^2','text']}}})
    t1 = time.time()
    hits = [{'id':h['_id'],'text':h['_source']['text']} for h in res['hits']['hits']]
    return hits, t1-t0

def rerank(query, passages):
    t0 = time.time()
    r = requests.post(RERANK_URL, json={'query':query,'passages':passages}).json()
    t1 = time.time()
    return r['ranked'], t1-t0

if __name__=='__main__':
    q = 'what is transfer learning'
    hits, t_r = retrieve(q, k=10)
    print('retrieval time',t_r,'hits',len(hits))
    ranked, t_rr = rerank(q, hits)
    print('rerank time',t_rr)
    print('top result',ranked[0])
