import requests

def rerank_demo():
    payload = {
        'query': 'what is transfer learning',
        'passages': [
            {'id':'a','text':'Transfer learning repurposes models trained on one task.'},
            {'id':'b','text':'Neural networks are layers of neurons.'}
        ]
    }
    r = requests.post('http://localhost:8100/rerank', json=payload)
    print(r.json())

if __name__=='__main__':
    rerank_demo()
