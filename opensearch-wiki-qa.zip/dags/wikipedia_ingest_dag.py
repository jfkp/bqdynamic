# dags/wikipedia_ingest_dag.py
from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime, timedelta

from wiki_ingest import run_wikipedia_ingest

default_args = {
    'owner': 'qa-team',
    'depends_on_past': False,
    'start_date': datetime(2025, 1, 1),
    'retries': 1,
    'retry_delay': timedelta(minutes=5)
}

dag = DAG('wikipedia_ingest', default_args=default_args, schedule_interval='@weekly')

ingest = PythonOperator(
    task_id='ingest_wikipedia_dump',
    python_callable=run_wikipedia_ingest,
    dag=dag
)
