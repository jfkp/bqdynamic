# OpenSearch + Wikipedia Q&A — Full Stack (Repository)

This repository contains a complete prototype and pipeline for integrating OpenSearch with Wikipedia for Q&A.

Quick steps:
1. Start OpenSearch and Dashboards:
   - `docker compose up -d`
2. Install Python deps:
   - `pip install -r api/requirements.txt`
3. Index sample docs:
   - `python ingest_sample.py`
4. Start reranker:
   - `uvicorn reranker_service:app --port 8100 --host 0.0.0.0`
5. Start QA API:
   - `uvicorn api/qa_service:app --port 8000 --host 0.0.0.0`
6. Test:
   - `curl -s -X POST http://localhost:8000/qa -H "Content-Type: application/json" -d '{"q":"what is transfer learning"}' | jq`

Notes:
- The wiki ingest parser is intentionally naive and for demo only. Use wikiextractor / mwxml for production parsing.
- Adjust embedding model dimensions if you change models.
