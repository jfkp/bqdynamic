# wiki_ingest.py
import os
import bz2
import requests
import tempfile
from opensearchpy import OpenSearch
from sentence_transformers import SentenceTransformer
from pathlib import Path

OPENSEARCH = os.getenv('OPENSEARCH_HOST','http://localhost:9200')
INDEX = 'docs'
EMBED_MODEL = 'all-MiniLM-L6-v2'

client = OpenSearch(OPENSEARCH)
model = SentenceTransformer(EMBED_MODEL)

WIKI_DUMP_URL = 'https://dumps.wikimedia.org/enwiki/latest/enwiki-latest-pages-articles.xml.bz2'

def download_dump(target_path):
    r = requests.get(WIKI_DUMP_URL, stream=True)
    with open(target_path, 'wb') as f:
        for chunk in r.iter_content(chunk_size=8192):
            f.write(chunk)

def parse_and_index(dump_path, max_pages=2000):
    with bz2.open(dump_path, 'rt', encoding='utf-8', errors='ignore') as fh:
        content = fh.read()
    pages = content.split('<page>')
    count = 0
    for p in pages[1: max_pages+1]:
        try:
            title = p.split('<title>')[1].split('</title>')[0]
            text = p.split('<text')[1].split('>')[1].split('</text>')[0]
        except Exception:
            continue
        chunks = [text[i:i+1500] for i in range(0,len(text),1500)]
        for i,ch in enumerate(chunks):
            emb = model.encode(ch).tolist()
            body = {
                'title': title,
                'text': ch,
                'metadata': {'page': title, 'chunk': i},
                'embedding': emb
            }
            client.index(index=INDEX, body=body)
        count += 1
    return count

def run_wikipedia_ingest():
    tmp = tempfile.mkdtemp()
    dump_path = Path(tmp)/'enwiki-latest-pages-articles.xml.bz2'
    download_dump(dump_path)
    n = parse_and_index(dump_path, max_pages=500)
    print(f'Indexed {n} pages (sample)')
