# ingest_sample.py
import json
from opensearchpy import OpenSearch
from sentence_transformers import SentenceTransformer

OPENSEARCH_HOST = "http://localhost:9200"
INDEX = "docs"
EMBED_DIM = 384

client = OpenSearch(OPENSEARCH_HOST)
model = SentenceTransformer("all-MiniLM-L6-v2")

# create index if not exists
with open("opensearch_mapping.json","r") as f:
    mapping = json.load(f)

if not client.indices.exists(INDEX):
    client.indices.create(index=INDEX, body=mapping)

# sample docs
docs = [
    {"title": "Transfer learning", "text": "Transfer learning is a technique in machine learning where a model trained on one task is repurposed on a second related task.", "metadata": {"source":"sample"}},
    {"title": "Neural networks", "text": "Neural networks are computing systems inspired by biological neural networks.", "metadata": {"source":"sample"}},
    {"title": "OpenSearch", "text": "OpenSearch is a community-driven, open source search and analytics suite derived from Elasticsearch.", "metadata": {"source":"sample"}}
]

for i,d in enumerate(docs):
    emb = model.encode(d["text"]).tolist()
    body = {"title": d["title"], "text": d["text"], "metadata": d["metadata"], "embedding": emb}
    client.index(index=INDEX, id=f"sample_{i}", body=body, refresh=True)

print("Indexed sample docs")
