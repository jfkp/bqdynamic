# reranker_service.py
from fastapi import FastAPI
from pydantic import BaseModel
from typing import List
from sentence_transformers import CrossEncoder

app = FastAPI()
model = CrossEncoder('cross-encoder/ms-marco-MiniLM-L-6-v2')

class Passage(BaseModel):
    id: str
    text: str

class RerankRequest(BaseModel):
    query: str
    passages: List[Passage]

@app.post('/rerank')
def rerank(req: RerankRequest):
    pairs = [(req.query, p.text) for p in req.passages]
    scores = model.predict(pairs)
    out = [{'id': p.id, 'score': float(s)} for p,s in zip(req.passages, scores)]
    out.sort(key=lambda x: x['score'], reverse=True)
    return {'ranked': out}
